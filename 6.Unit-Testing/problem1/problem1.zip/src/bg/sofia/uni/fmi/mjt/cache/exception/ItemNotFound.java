package bg.sofia.uni.fmi.mjt.cache.exception;

public class ItemNotFound extends Exception {
    public ItemNotFound(String msg) {
        super(msg);
    }
}