package bg.sofia.uni.fmi.mjt.cache.factory;

public enum EvictionPolicy {
    LEAST_RECENTLY_USED, LEAST_FREQUENTLY_USED
}